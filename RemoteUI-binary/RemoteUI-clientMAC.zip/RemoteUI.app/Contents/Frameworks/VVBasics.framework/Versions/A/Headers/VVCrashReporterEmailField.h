#import <Cocoa/Cocoa.h>
#import <AppKit/AppKit.h>


/*
	this class exists solely to prevent users from pasting huge amounts of text into the email field
*/


@interface VVCrashReporterEmailField : NSTextField {

}

@end
